#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "mysql.h"
#include <string.h>
#include <string>
#include <stdlib.h>
#include <iostream>
//using namespace std; 

#pragma comment(lib, "libmysql.lib")

const char* host = "localhost";
const char* user = "root";
const char* pw = "98rldnddbs@@";
const char* db = "asdfa";

int main(void) {

	MYSQL* connection = NULL;
	MYSQL conn;
	MYSQL_RES* sql_result;
	MYSQL_ROW sql_row;


	const char* inputquery; 
	int type; 


	if (mysql_init(&conn) == NULL) 		printf("mysql_init() error!");


	connection = mysql_real_connect(&conn, host, user, pw, db, 3306, (const char*)NULL, 0);
	if (connection == NULL)
	{
		printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
		return 1;
	}

	else
	{
		//printf("Connection Succeed\n");
		if (mysql_select_db(&conn, db))
		{
			printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
			return 1;
		}

		//const char* query = "select * from pacge";
		FILE* fp = NULL; 
		//FILE* fp1 = NULL; 
		fp = fopen("dbtxt23.txt", "r"); 
		//fp1 = fopen("dbtxt2.txt", "r"); 
		if (fp != NULL) {
			char makeline[500]; 
			while (!feof(fp)) {
				inputquery = fgets(makeline, sizeof(makeline), fp);
				//printf("%s\n", inputquery); 
				mysql_query(connection, inputquery);
			}

			fclose(fp); 
		}
		//if(fp1 != NULL) {
		//	char makeline2[255];
		//	while (!feof(fp1)) {
		//		inputquery = fgets(makeline2, sizeof(makeline2), fp1);
		//		//printf("%s\n", inputquery); 
		//		mysql_query(connection, inputquery);
		//	}
		//	fclose(fp1);
		//}
		while (1) 
		{

			printf("------- SELECT QUERY TYPES -------\n\n");
			printf("\t1. TYPE 1\n");
			printf("\t2. TYPE 2\n");
			printf("\t3. TYPE 3\n");
			printf("\t4. TYPE 4\n");
			printf("\t5. TYPE 5\n");
			printf("\t6. TYPE 6\n");
			printf("\t7. TYPE 7\n");
			printf("\t0. QUIT\n");
			printf("Which type of query? ");
			printf("----------------------------------\n");
			scanf("%d", &type);  
			printf("\n"); 
		
			if (type == 0) {
				printf("\t0. QUIT\n");
				return 0; 
			}
			else if (type == 1) {
				int trucknum; 
				printf("---- TYPE I ----\n"); // choice�� 1�� �ش��ϴ� ���, subtype�� ������. 
				printf("Input the number of Transport : ");
				scanf("%d", &trucknum); 
				printf("%d", trucknum);
				//return 0; 
				if (trucknum != 1721) {
					printf("there is no destroied one \n"); 
					continue; 
				}
				while (1) 
				{
					int typeone; 
					printf("\n---- Subtypes in TYPE I----\n");
					printf("\t1. TYPE I-1\n");
					printf("\t2. TYPE I-2\n");
					printf("\t3. TYPE I-3\n");
					printf("Which type of query? ");
					scanf("%d", &typeone);
					if (typeone == 0) {
						break; 
					}
					if (typeone == 1) {
						printf("\n---- TYPE I-1 ----\n");
						printf("** Find all customers who had a package on the truck at the time of the crash. **\n");
						printf("Customer ID: ");
						char query1_1[300] = "select p.CustomerID from package p, shipment s , trace t where s.ShipmentID = t.ShipmentID and p.PackageID = s.PackageID and t.complete = 3 and t.vin =1721 ";
						int check1_1 = 0; 
						check1_1 = mysql_query(connection, query1_1);
						if (check1_1 == 0) {
							sql_result = mysql_store_result(connection);
							while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
							{
								printf("%s | ", sql_row[0]);
							}
							mysql_free_result(sql_result);
						}
						printf("\n\n"); 
						continue; 
					}
					if (typeone == 2) {
						printf("\n---- TYPE I-2 ----\n");
						printf("** Find all recipients who had a package on the truck at the time of the crash. **\n");
						printf(" recipients name :  ");
						char query1_2[300] = "select s.recname from shipment s , trace t where s.ShipmentID = t.ShipmentID and t.complete = 3 and t.vin = 1721"; 
						int check1_2 = 0; 
						check1_2= mysql_query(connection, query1_2);
						if (check1_2 == 0) {
							sql_result = mysql_store_result(connection);
							while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
							{
								printf("%s | ", sql_row[0]);
							}
							mysql_free_result(sql_result);
						}
						printf("\n\n");
						//continue;

					}
					if (typeone == 3) {
						printf("\n---- TYPE I-3 ----\n");
						printf("** Find the last successful delivery by that truck prior to the crash. **\n");
						printf("Last Successful Delivery on: ");
						char query13[300] = "SELECT t1.Goal, t1.DateeTime FROM trace t1, trace t2 WHERE t2.DateeTime > t1.DateeTime AND t2.Complete = 3 AND t2.VIN = 1721 AND t1.VIN = 1721 order by t1.dateetime limit 1";
						int check13 = 0; 
						check13 = mysql_query(connection, query13);
						if (check13 == 0) {
							sql_result = mysql_store_result(connection);
							while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
							{
								printf("%s | %s ", sql_row[0], sql_row[1]);
							}
							mysql_free_result(sql_result);
						}
						printf("\n\n");
					}
				}
				break; 
			}
			
			else if (type == 2)
			{
				int year;
				printf("---- TYPE II ----\n");
				while (1)
				{
					printf("** Find the customer who has shipped the most packages in certain year **\n");
					printf("Which Year? : ");
					scanf("%d", &year);
					printf("%d\n", year); 
					char yearStr[5];
					sprintf(yearStr, "%d", year);
					char query2[300] = "select * from (select customerID , count(*) as packagecnt from package  where Year(orderdate) = ";
					strcat(query2, yearStr);
					strcat(query2, " group by customerID)subq order by packagecnt desc limit 1");
					printf("Customer ID: ");
					int check2 = 0;
					check2 = mysql_query(connection, query2);
					if (check2 == 0)
					{
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%s ", sql_row[0]);
						}

						mysql_free_result(sql_result);
					}
				}

				printf("\n\n"); 
			}//type =2 
			else if (type == 3)
			{
				printf("---- TYPE III ----\n");
				int year2; 
				while (1)
				{
					printf("** Find the customer who has spent the most money on shipping in the past certian year **\n");
					printf("Which Year? : ");
					scanf("%d", &year2); 
					char yearstr[5]; 
					sprintf(yearstr, "%d", year2);
					char query3[500] = "SELECT t1.customerID, SUM(t1.TotalCharge) AS chargesum FROM bill t1 JOIN payment t2 ON t1.billID = t2.billID WHERE YEAR(t2.PayDate) = "; 
					strcat(query3, yearstr);
					strcat(query3, " GROUP BY t1.customerID HAVING SUM(t1.TotalCharge)=(SELECT MAX(total_chargesum) FROM ( SELECT SUM(t1.TotalCharge) AS total_chargesum  FROM bill t1 JOIN payment t2 ON t1.billID = t2.billID WHERE YEAR(t2.PayDate) = ");
					strcat(query3, yearstr); 
					strcat(query3, " GROUP BY t1.customerID) AS subquery) ORDER BY chargesum DESC");
					int check3 = 0;
					check3 = mysql_query(connection, query3);
					if (check3 == 0)
					{
						sql_result = mysql_store_result(connection);
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%s %s ", sql_row[0], sql_row[1]);
						}

						mysql_free_result(sql_result);
					}
					printf("is the customer you are finding \n"); 

				}
			}//type = 3 
			else if (type == 4) 
			{
				printf("---- TYPE IV ----\n\n");
				printf("** Find those packages that were not delivered within the promised time**\n");
				char query4[300] = "select t1.packageid from shipment t1, shipment t2 where t1.ShipmentID= t2.ShipmentID and t1.PromiseDate< t2.arriveddate";
				int check4 = 0; 
				check4 = mysql_query(connection, query4);
				if (check4 == 0)
				{
					sql_result = mysql_store_result(connection);
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						printf("%s | ", sql_row[0]);
					}
					mysql_free_result(sql_result);
				}
				printf("\n\n"); 
			}
			else {
				printf("not right num\n"); 

			}
		
		 }//type �޴� �� 

		mysql_close(connection);
	}
	free(fp1); 
	FILE* fp2 = NULL; 
	fp2 = fopen("dbtxt3.txt", "r"); 
	
	if (fp2 != NULL) {
		char endline[300]; 
		while (!feof(fp2)) {
			inputquery = fgets(endline, sizeof(endline), fp2); 
			mysql_query(connection, inputquery);
		}
		fclose(fp2); 
	}
	return 0;
}



